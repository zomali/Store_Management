﻿CREATE TABLE [dbo].[Client_Item] (
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [ItemID]       NVARCHAR (50)  NULL,
    [ClientID]     INT            NULL,
    [Delivery_Way] NVARCHAR (50)  NULL,
    [Status]       NVARCHAR (50)  NULL,
    [Notes]        NVARCHAR (MAX) NULL,
    [Date]         NVARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC),
    FOREIGN KEY ([ItemID]) REFERENCES [dbo].[Item] ([ID]),
    FOREIGN KEY ([ClientID]) REFERENCES [dbo].[Client] ([ID])
);

