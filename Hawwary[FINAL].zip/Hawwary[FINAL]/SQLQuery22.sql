﻿CREATE TABLE [dbo].[representative]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, 
    [representative] NVARCHAR(50) NOT NULL
)
