﻿SET IDENTITY_INSERT [dbo].[Color] ON
INSERT INTO [dbo].[Color] ([ID], [Color]) VALUES (2, N'')
SET IDENTITY_INSERT [dbo].[Color] OFF
