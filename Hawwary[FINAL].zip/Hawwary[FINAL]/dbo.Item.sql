﻿CREATE TABLE [dbo].[Item] (
    [ID]          NVARCHAR (50) NOT NULL,
    [Brand]       NVARCHAR (50) NULL,
    [Type]        NVARCHAR (50) NULL,
    [gender]      NVARCHAR (50) NULL,
    [Store_Count] INT           NULL,
    [Price]       FLOAT (53)    NULL,
    [Season]      NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

