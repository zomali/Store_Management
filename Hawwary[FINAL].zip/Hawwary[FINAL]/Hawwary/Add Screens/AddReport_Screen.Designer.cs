﻿namespace Hawwary.Add_Screens
{
    partial class AddReport_Screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddReport_Screen));
            this.ADD_Representative = new System.Windows.Forms.ToolStripMenuItem();
            this.Add_User = new System.Windows.Forms.ToolStripMenuItem();
            this.names_box = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.Save_btn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cancel_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.line_txt = new System.Windows.Forms.TextBox();
            this.delivery_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.NumOfItems_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.itemBack_txt = new System.Windows.Forms.TextBox();
            this.still_txt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Notes_txt = new System.Windows.Forms.TextBox();
            this.MoneyBack_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.givenMoney_txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.discount_txt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.total_txt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.DateTime_txt = new System.Windows.Forms.TextBox();
            this.update_btn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Add_Client_btn = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.MainBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel11 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel12 = new System.Windows.Forms.ToolStripLabel();
            this.AddPaymentBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.ClientSearch = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.AddClientBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.StoreDetails = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.AddItemBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel10 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel13 = new System.Windows.Forms.ToolStripLabel();
            this.AddReport_Btn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel14 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel15 = new System.Windows.Forms.ToolStripLabel();
            this.showBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel16 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel17 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel18 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.Add_Client_btn.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripDropDownButton1
            // 
            toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ADD_Representative,
            this.Add_User});
            toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            toolStripDropDownButton1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            toolStripDropDownButton1.Size = new System.Drawing.Size(159, 29);
            toolStripDropDownButton1.Text = "الإعدادات";
            toolStripDropDownButton1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // ADD_Representative
            // 
            this.ADD_Representative.Name = "ADD_Representative";
            this.ADD_Representative.Size = new System.Drawing.Size(328, 30);
            this.ADD_Representative.Text = "إضافة مستخدم او مندوب جديد";
            this.ADD_Representative.Click += new System.EventHandler(this.ADD_Representative_Click);
            // 
            // Add_User
            // 
            this.Add_User.Name = "Add_User";
            this.Add_User.Size = new System.Drawing.Size(328, 30);
            this.Add_User.Text = "تغيير كلمة السر";
            this.Add_User.Click += new System.EventHandler(this.Add_User_Click);
            // 
            // names_box
            // 
            this.names_box.Cursor = System.Windows.Forms.Cursors.Hand;
            this.names_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.names_box.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.names_box.Location = new System.Drawing.Point(806, 152);
            this.names_box.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.names_box.Name = "names_box";
            this.names_box.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.names_box.Size = new System.Drawing.Size(261, 26);
            this.names_box.TabIndex = 47;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(480, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(111, 94);
            this.panel1.TabIndex = 63;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(666, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(298, 54);
            this.label8.TabIndex = 64;
            this.label8.Text = "Hawwary Online Store";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Save_btn
            // 
            this.Save_btn.BackColor = System.Drawing.Color.Chocolate;
            this.Save_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Save_btn.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Save_btn.Location = new System.Drawing.Point(471, 636);
            this.Save_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(340, 70);
            this.Save_btn.TabIndex = 53;
            this.Save_btn.Text = "حــــــــــــــــــــــــــــفــــــــــــــــــــــــــــظ";
            this.Save_btn.UseVisualStyleBackColor = false;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(447, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 24);
            this.label9.TabIndex = 61;
            this.label9.Text = "التاريخ";
            // 
            // cancel_txt
            // 
            this.cancel_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cancel_txt.Location = new System.Drawing.Point(806, 501);
            this.cancel_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cancel_txt.Name = "cancel_txt";
            this.cancel_txt.Size = new System.Drawing.Size(261, 26);
            this.cancel_txt.TabIndex = 48;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(1114, 571);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 24);
            this.label6.TabIndex = 59;
            this.label6.Text = "ملاحظات";
            // 
            // line_txt
            // 
            this.line_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.line_txt.Location = new System.Drawing.Point(130, 153);
            this.line_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.line_txt.Name = "line_txt";
            this.line_txt.Size = new System.Drawing.Size(263, 26);
            this.line_txt.TabIndex = 44;
            // 
            // delivery_txt
            // 
            this.delivery_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.delivery_txt.Location = new System.Drawing.Point(805, 287);
            this.delivery_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.delivery_txt.Name = "delivery_txt";
            this.delivery_txt.Size = new System.Drawing.Size(263, 26);
            this.delivery_txt.TabIndex = 46;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(455, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 24);
            this.label5.TabIndex = 58;
            this.label5.Text = "الخط";
            // 
            // NumOfItems_txt
            // 
            this.NumOfItems_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NumOfItems_txt.Location = new System.Drawing.Point(805, 222);
            this.NumOfItems_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.NumOfItems_txt.Name = "NumOfItems_txt";
            this.NumOfItems_txt.Size = new System.Drawing.Size(263, 26);
            this.NumOfItems_txt.TabIndex = 45;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(1107, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 24);
            this.label4.TabIndex = 57;
            this.label4.Text = "عدد القطع";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(1129, 500);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 24);
            this.label3.TabIndex = 56;
            this.label3.Text = "ملغي";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(1130, 290);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 24);
            this.label2.TabIndex = 55;
            this.label2.Text = "تسلم";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(1094, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 24);
            this.label1.TabIndex = 54;
            this.label1.Text = "أسم المندوب";
            // 
            // itemBack_txt
            // 
            this.itemBack_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.itemBack_txt.Location = new System.Drawing.Point(805, 424);
            this.itemBack_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.itemBack_txt.Name = "itemBack_txt";
            this.itemBack_txt.Size = new System.Drawing.Size(263, 26);
            this.itemBack_txt.TabIndex = 66;
            // 
            // still_txt
            // 
            this.still_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.still_txt.Location = new System.Drawing.Point(805, 362);
            this.still_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.still_txt.Name = "still_txt";
            this.still_txt.Size = new System.Drawing.Size(263, 26);
            this.still_txt.TabIndex = 65;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(1130, 362);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 24);
            this.label10.TabIndex = 68;
            this.label10.Text = "تأجيل";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(1127, 427);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 24);
            this.label11.TabIndex = 67;
            this.label11.Text = "مرتجع";
            // 
            // Notes_txt
            // 
            this.Notes_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Notes_txt.Location = new System.Drawing.Point(806, 568);
            this.Notes_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Notes_txt.Name = "Notes_txt";
            this.Notes_txt.Size = new System.Drawing.Size(261, 26);
            this.Notes_txt.TabIndex = 69;
            // 
            // MoneyBack_txt
            // 
            this.MoneyBack_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MoneyBack_txt.Location = new System.Drawing.Point(131, 366);
            this.MoneyBack_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MoneyBack_txt.Name = "MoneyBack_txt";
            this.MoneyBack_txt.Size = new System.Drawing.Size(261, 26);
            this.MoneyBack_txt.TabIndex = 71;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(404, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 24);
            this.label7.TabIndex = 72;
            this.label7.Text = "قيمة المرتجعات";
            // 
            // givenMoney_txt
            // 
            this.givenMoney_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.givenMoney_txt.Location = new System.Drawing.Point(131, 439);
            this.givenMoney_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.givenMoney_txt.Name = "givenMoney_txt";
            this.givenMoney_txt.Size = new System.Drawing.Size(261, 26);
            this.givenMoney_txt.TabIndex = 73;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(400, 438);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(165, 24);
            this.label12.TabIndex = 74;
            this.label12.Text = "قيمة المصروفات";
            // 
            // discount_txt
            // 
            this.discount_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.discount_txt.Location = new System.Drawing.Point(131, 501);
            this.discount_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.discount_txt.Name = "discount_txt";
            this.discount_txt.Size = new System.Drawing.Size(261, 26);
            this.discount_txt.TabIndex = 75;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(403, 504);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(158, 24);
            this.label13.TabIndex = 76;
            this.label13.Text = "قيمة الخصومات";
            // 
            // total_txt
            // 
            this.total_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.total_txt.Location = new System.Drawing.Point(130, 291);
            this.total_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.total_txt.Name = "total_txt";
            this.total_txt.Size = new System.Drawing.Size(263, 26);
            this.total_txt.TabIndex = 77;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(435, 291);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 24);
            this.label14.TabIndex = 78;
            this.label14.Text = "الاجمالي";
            // 
            // DateTime_txt
            // 
            this.DateTime_txt.Enabled = false;
            this.DateTime_txt.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DateTime_txt.Location = new System.Drawing.Point(130, 224);
            this.DateTime_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DateTime_txt.Name = "DateTime_txt";
            this.DateTime_txt.Size = new System.Drawing.Size(263, 26);
            this.DateTime_txt.TabIndex = 79;
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.Color.Chocolate;
            this.update_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.update_btn.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.update_btn.Location = new System.Drawing.Point(471, 670);
            this.update_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(340, 70);
            this.update_btn.TabIndex = 80;
            this.update_btn.Text = "تـــــــــــــــحــــــــــــــــــد يــــــــــــــــــــث";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Visible = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Chocolate;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(471, 636);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(340, 70);
            this.button1.TabIndex = 53;
            this.button1.Text = "حــــــــــــــــــــــــــــفــــــــــــــــــــــــــــظ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Chocolate;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(471, 670);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(340, 70);
            this.button2.TabIndex = 80;
            this.button2.Text = "تـــــــــــــــحــــــــــــــــــد يــــــــــــــــــــث";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(50, 30);
            this.button3.Name = "button3";
            this.button3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button3.Size = new System.Drawing.Size(70, 70);
            this.button3.TabIndex = 81;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Add_Client_btn
            // 
            this.Add_Client_btn.BackColor = System.Drawing.Color.Tan;
            this.Add_Client_btn.Dock = System.Windows.Forms.DockStyle.Right;
            this.Add_Client_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add_Client_btn.GripMargin = new System.Windows.Forms.Padding(0);
            this.Add_Client_btn.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Add_Client_btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.MainBtn,
            this.toolStripLabel11,
            this.toolStripSeparator6,
            this.toolStripLabel12,
            this.AddPaymentBtn,
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.toolStripLabel6,
            this.ClientSearch,
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripLabel7,
            this.AddClientBtn,
            this.toolStripLabel3,
            this.toolStripSeparator3,
            this.toolStripLabel8,
            this.StoreDetails,
            this.toolStripLabel5,
            this.toolStripSeparator4,
            this.toolStripLabel9,
            this.AddItemBtn,
            this.toolStripLabel10,
            this.toolStripSeparator5,
            this.toolStripLabel13,
            this.AddReport_Btn,
            this.toolStripLabel14,
            this.toolStripSeparator7,
            this.toolStripLabel15,
            this.showBtn,
            this.toolStripLabel16,
            this.toolStripSeparator8,
            this.toolStripLabel17,
            toolStripDropDownButton1,
            this.toolStripLabel18,
            this.toolStripSeparator9});
            this.Add_Client_btn.Location = new System.Drawing.Point(1322, 0);
            this.Add_Client_btn.Name = "Add_Client_btn";
            this.Add_Client_btn.Padding = new System.Windows.Forms.Padding(0);
            this.Add_Client_btn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Add_Client_btn.Size = new System.Drawing.Size(160, 753);
            this.Add_Client_btn.Stretch = true;
            this.Add_Client_btn.TabIndex = 82;
            this.Add_Client_btn.Text = "الشاشة الرئيسية";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.AutoSize = false;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripLabel4.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel4.Text = " ";
            // 
            // MainBtn
            // 
            this.MainBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MainBtn.Image = ((System.Drawing.Image)(resources.GetObject("MainBtn.Image")));
            this.MainBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainBtn.Name = "MainBtn";
            this.MainBtn.Size = new System.Drawing.Size(159, 29);
            this.MainBtn.Text = "الشاشة الرئيسية";
            this.MainBtn.Click += new System.EventHandler(this.MainBtn_Click);
            // 
            // toolStripLabel11
            // 
            this.toolStripLabel11.AutoSize = false;
            this.toolStripLabel11.Enabled = false;
            this.toolStripLabel11.Name = "toolStripLabel11";
            this.toolStripLabel11.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel11.Text = " ";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel12
            // 
            this.toolStripLabel12.AutoSize = false;
            this.toolStripLabel12.Enabled = false;
            this.toolStripLabel12.Name = "toolStripLabel12";
            this.toolStripLabel12.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel12.Text = " ";
            // 
            // AddPaymentBtn
            // 
            this.AddPaymentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPaymentBtn.Image = ((System.Drawing.Image)(resources.GetObject("AddPaymentBtn.Image")));
            this.AddPaymentBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPaymentBtn.Name = "AddPaymentBtn";
            this.AddPaymentBtn.Size = new System.Drawing.Size(159, 29);
            this.AddPaymentBtn.Text = "عملية شراء جديدة";
            this.AddPaymentBtn.Click += new System.EventHandler(this.AddPaymentBtn_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.AutoSize = false;
            this.toolStripLabel1.Enabled = false;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel1.Text = "          ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.AutoSize = false;
            this.toolStripLabel6.Enabled = false;
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel6.Text = " ";
            // 
            // ClientSearch
            // 
            this.ClientSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ClientSearch.Image = ((System.Drawing.Image)(resources.GetObject("ClientSearch.Image")));
            this.ClientSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClientSearch.Name = "ClientSearch";
            this.ClientSearch.Size = new System.Drawing.Size(159, 29);
            this.ClientSearch.Text = "البحث عن عميل";
            this.ClientSearch.Click += new System.EventHandler(this.ClientSearch_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.AutoSize = false;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel2.Text = "   ";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.AutoSize = false;
            this.toolStripLabel7.Enabled = false;
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel7.Text = " ";
            // 
            // AddClientBtn
            // 
            this.AddClientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddClientBtn.Image = ((System.Drawing.Image)(resources.GetObject("AddClientBtn.Image")));
            this.AddClientBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddClientBtn.Name = "AddClientBtn";
            this.AddClientBtn.Size = new System.Drawing.Size(159, 29);
            this.AddClientBtn.Text = "إضافة عميل";
            this.AddClientBtn.Click += new System.EventHandler(this.AddClientBtn_Click);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.AutoSize = false;
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel3.Text = "  ";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.AutoSize = false;
            this.toolStripLabel8.Enabled = false;
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel8.Text = " ";
            // 
            // StoreDetails
            // 
            this.StoreDetails.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StoreDetails.Image = ((System.Drawing.Image)(resources.GetObject("StoreDetails.Image")));
            this.StoreDetails.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StoreDetails.Name = "StoreDetails";
            this.StoreDetails.Size = new System.Drawing.Size(159, 29);
            this.StoreDetails.Text = "عرض المخزن";
            this.StoreDetails.Click += new System.EventHandler(this.StoreDetails_Click);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.AutoSize = false;
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel5.Text = " ";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.AutoSize = false;
            this.toolStripLabel9.Enabled = false;
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel9.Text = " ";
            // 
            // AddItemBtn
            // 
            this.AddItemBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddItemBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddItemBtn.Name = "AddItemBtn";
            this.AddItemBtn.Size = new System.Drawing.Size(159, 29);
            this.AddItemBtn.Text = "إضافة قطعة جديدة";
            this.AddItemBtn.Click += new System.EventHandler(this.AddItemBtn_Click);
            // 
            // toolStripLabel10
            // 
            this.toolStripLabel10.AutoSize = false;
            this.toolStripLabel10.Enabled = false;
            this.toolStripLabel10.Name = "toolStripLabel10";
            this.toolStripLabel10.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel10.Text = " ";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel13
            // 
            this.toolStripLabel13.AutoSize = false;
            this.toolStripLabel13.Enabled = false;
            this.toolStripLabel13.Name = "toolStripLabel13";
            this.toolStripLabel13.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel13.Text = " ";
            // 
            // AddReport_Btn
            // 
            this.AddReport_Btn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddReport_Btn.Image = ((System.Drawing.Image)(resources.GetObject("AddReport_Btn.Image")));
            this.AddReport_Btn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddReport_Btn.Name = "AddReport_Btn";
            this.AddReport_Btn.Size = new System.Drawing.Size(159, 29);
            this.AddReport_Btn.Text = "إضافة تقرير";
            this.AddReport_Btn.Click += new System.EventHandler(this.AddReport_Btn_Click);
            // 
            // toolStripLabel14
            // 
            this.toolStripLabel14.AutoSize = false;
            this.toolStripLabel14.Enabled = false;
            this.toolStripLabel14.Name = "toolStripLabel14";
            this.toolStripLabel14.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel14.Text = " ";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel15
            // 
            this.toolStripLabel15.AutoSize = false;
            this.toolStripLabel15.Enabled = false;
            this.toolStripLabel15.Name = "toolStripLabel15";
            this.toolStripLabel15.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel15.Text = " ";
            // 
            // showBtn
            // 
            this.showBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.showBtn.Image = ((System.Drawing.Image)(resources.GetObject("showBtn.Image")));
            this.showBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.showBtn.Name = "showBtn";
            this.showBtn.Size = new System.Drawing.Size(159, 29);
            this.showBtn.Text = "عرض التقارير";
            this.showBtn.Click += new System.EventHandler(this.showBtn_Click);
            // 
            // toolStripLabel16
            // 
            this.toolStripLabel16.AutoSize = false;
            this.toolStripLabel16.Enabled = false;
            this.toolStripLabel16.Name = "toolStripLabel16";
            this.toolStripLabel16.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel16.Text = " ";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel17
            // 
            this.toolStripLabel17.AutoSize = false;
            this.toolStripLabel17.Enabled = false;
            this.toolStripLabel17.Name = "toolStripLabel17";
            this.toolStripLabel17.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel17.Text = " ";
            // 
            // toolStripLabel18
            // 
            this.toolStripLabel18.AutoSize = false;
            this.toolStripLabel18.Enabled = false;
            this.toolStripLabel18.Name = "toolStripLabel18";
            this.toolStripLabel18.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel18.Text = " ";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(159, 6);
            // 
            // AddReport_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.Add_Client_btn);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.DateTime_txt);
            this.Controls.Add(this.total_txt);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.discount_txt);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.givenMoney_txt);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.MoneyBack_txt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Notes_txt);
            this.Controls.Add(this.itemBack_txt);
            this.Controls.Add(this.still_txt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.names_box);
            this.Controls.Add(this.Save_btn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cancel_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.line_txt);
            this.Controls.Add(this.delivery_txt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.NumOfItems_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1500, 800);
            this.MinimumSize = new System.Drawing.Size(1500, 800);
            this.Name = "AddReport_Screen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "إضافة تقرير";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddReport_Screen_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddReport_Screen_FormClosed);
            this.Load += new System.EventHandler(this.AddReport_Screen_Load);
            this.Add_Client_btn.ResumeLayout(false);
            this.Add_Client_btn.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Panel panel1;
        private Label label8;
        public Button Save_btn;
        private Label label9;
        public TextBox cancel_txt;
        private Label label6;
        public TextBox line_txt;
        public TextBox delivery_txt;
        private Label label5;
        public TextBox NumOfItems_txt;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        public TextBox itemBack_txt;
        public TextBox still_txt;
        private Label label10;
        private Label label11;
        public TextBox Notes_txt;
        public TextBox MoneyBack_txt;
        private Label label7;
        public TextBox givenMoney_txt;
        private Label label12;
        public TextBox discount_txt;
        private Label label13;
        public TextBox total_txt;
        private Label label14;
        public TextBox DateTime_txt;
        public Button update_btn;
        public Button button1;
        public Button button2;
        private Button button3;
        private ToolStrip Add_Client_btn;
        private ToolStripLabel toolStripLabel4;
        private ToolStripButton MainBtn;
        private ToolStripLabel toolStripLabel11;
        private ToolStripSeparator toolStripSeparator6;
        private ToolStripLabel toolStripLabel12;
        private ToolStripButton AddPaymentBtn;
        private ToolStripLabel toolStripLabel1;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripLabel toolStripLabel6;
        private ToolStripButton ClientSearch;
        private ToolStripLabel toolStripLabel2;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripLabel toolStripLabel7;
        public ToolStripButton AddClientBtn;
        private ToolStripLabel toolStripLabel3;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripLabel toolStripLabel8;
        private ToolStripButton StoreDetails;
        private ToolStripLabel toolStripLabel5;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripLabel toolStripLabel9;
        private ToolStripButton AddItemBtn;
        private ToolStripLabel toolStripLabel10;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripLabel toolStripLabel13;
        private ToolStripButton AddReport_Btn;
        private ToolStripLabel toolStripLabel14;
        private ToolStripSeparator toolStripSeparator7;
        private ToolStripLabel toolStripLabel15;
        private ToolStripButton showBtn;
        private ToolStripLabel toolStripLabel16;
        private ToolStripSeparator toolStripSeparator8;
        private ToolStripLabel toolStripLabel17;
        private ToolStripMenuItem ADD_Representative;
        private ToolStripMenuItem Add_User;
        private ToolStripLabel toolStripLabel18;
        private ToolStripSeparator toolStripSeparator9;
        public ComboBox names_box;
    }
}