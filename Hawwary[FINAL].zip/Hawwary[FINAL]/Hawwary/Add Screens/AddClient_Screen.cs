﻿using Hawwary.Add_Screens;
using MissionsDB.MassageBox;
using MissionsDB.messagebox;
using System.Data;
using System.Data.SqlClient;

namespace Hawwary
{
    public partial class AddClient_Screen : Form
    {

        String query;
        SqlConnection con;
        SqlDataAdapter DataAdapter;
        string connection_string;
        public string MyPage;
        public AddClient_Screen()
        {
            InitializeComponent();
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
            MyPage = "AddClient";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            try
            {

                string q= "Select Telephone  from Client Where Telephone ='" + phone_txt.Text.Trim()+"'";
                SqlCommand  command = new SqlCommand(q, con);
                command.CommandType = CommandType.Text;
                 DataAdapter = new SqlDataAdapter();
                // Set the SqlDataAdapter's SelectCommand.
                DataAdapter.SelectCommand = command;

                // Fill the DataSet.
                DataSet dataSet = new DataSet();
                DataAdapter.Fill(dataSet, "Client");
                DataRow dataRow = dataSet.Tables["Client"].Rows[0];

                string phone = dataRow["Telephone"].ToString();
                if (phone == phone_txt.Text.Trim())
                {
                  
                    ERROR_WIN FoRM = new ERROR_WIN("هذا العميل موجود بالفعل");
                    FoRM.ShowDialog(this);
                    return;
                    //   MessageBox.Show("هذا العميل موجود بالفعل ");
                    return;

                }

            }
            catch {
                try
                {
                    int num=int.Parse(phone_txt.Text.Trim());
                    num=int.Parse((taxes_txt.Text.Trim()));
                    if (name_txt.Text.Trim() != "" && phone_txt.Text.Trim() != "")
                    {
                       
                        if (con.State == ConnectionState.Closed)
                        {
                            con.Open();
                        }
                        string query = "Insert into Client" +
                            " (Name," +
                            "Telephone, " +
                            "Address," +
                            "Delivery_Charges," +
                            "Notes" +
                            ")" +
                            "Values" +
                            "(" +
                            "'" + name_txt.Text + "'," +
                            "'" + phone_txt.Text + "'," +
                             "'" + address_txt.Text + "'," +
                              "'" + taxes_txt.Text + "'," +
                              "'" + notes_txt.Text + "')";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                       
                        MASSAGE_WIN FRM = new MASSAGE_WIN("تم اضافة بيانات العميل بنجاح");
                        FRM.ShowDialog(this);

                    }
                    else
                    {
                        ERROR_WIN FoRM = new ERROR_WIN("يجب إدخال أسم العميل ورقم الموبايل");
                        FoRM.ShowDialog(this);
                        return;
                    }
                }
                catch
                {
                    ERROR_WIN FoRM = new ERROR_WIN("خطأ في إدخال البيانات");
                    FoRM.ShowDialog(this);
                    return;
                }
            }
          

        }

        private void AddClient_Screen_Load(object sender, EventArgs e)
        {
            AddClientBtn.BackColor = Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            AddClientBtn.Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold);
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();
             
                form.Show();
                this.Hide();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();
                
                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;
               
                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();
                
                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
              
                clientSearch_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();
                
                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddClient_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen=new MainWindwo_Screen();
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();

                clientSearch_Screen.Show();
                this.Hide();
            }
        }

        private void AddClientBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void AddReport_Btn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }
    }
}