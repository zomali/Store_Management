﻿using MissionsDB.MassageBox;
using MissionsDB.messagebox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hawwary.Add_Screens
{
    public partial class AddReport_Screen : Form
    {
        String query;
        SqlConnection con;
        SqlDataAdapter DataAdapter;
        string connection_string;
        public string MyPage;
        public string representative_id;
        public AddReport_Screen()
        {
            InitializeComponent();
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
            MyPage = "AddReport";
            DateTime_txt.Text = DateTime.Now.ToShortDateString().ToString();
        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            if(names_box.Text.Trim() == ""|| total_txt.Text.Trim() == "" || NumOfItems_txt.Text.Trim() == "")
            {
                ERROR_WIN FOORM = new ERROR_WIN("خطأ في إدخال البيانات");
                FOORM.ShowDialog(this);
                return;
            }
            try
            {
             //   if (name_txt.Text.Trim() != "" && phone_txt.Text.Trim() != "")
                {
                    connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
                    con = new SqlConnection(connection_string);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Insert into Report" +
                        " (Name," +
                        "Amount, " +
                        "Money_Back," +
                        "discount," +
                        "Given_Money," +
                        "Line," +
                        "Num_Of_Items," +
                        "Delivery," +
                        "Still," +
                         "Cancel," +
                        "Notes," +
                         "Date" +
                        ")" +
                        "Values" +
                        "(" +
                        "'" + names_box.Text.Trim() + "'," +
                        "'" + total_txt.Text.Trim() + "'," +
                         "'" + MoneyBack_txt.Text.Trim() + "'," +
                        "'" + discount_txt.Text.Trim() + "'," +
                        "'" + givenMoney_txt.Text.Trim() + "'," +
                        "'" + line_txt.Text.Trim() + "'," +
                        "'" + NumOfItems_txt.Text.Trim() + "'," +
                        "'" + delivery_txt.Text.Trim() + "'," +
                         "'" + still_txt.Text.Trim() + "'," +
                         "'" + cancel_txt.Text.Trim() + "'," +
                        "'" + Notes_txt.Text.Trim() + "'," +

                          "'" + DateTime_txt.Text.Trim() + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
              
                    MASSAGE_WIN FRM = new MASSAGE_WIN("تم اضافة بيانات العميل بنجاح");
                    FRM.ShowDialog(this);
                }
        //     
            }
            catch
            {
                ERROR_WIN FOORM = new ERROR_WIN("خطأ في إدخال البيانات");
                FOORM.ShowDialog(this);
                return;
            }
        }

        private void AddReport_Screen_Load(object sender, EventArgs e)
        {
            //     DateTime_box.Value.;
            AddReport_Btn.BackColor = Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            AddReport_Btn.Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold);
            if (update_btn.Visible == true)
            {
                names_box.DropDownStyle = ComboBoxStyle.DropDown;

            }
            else
                names_box.DropDownStyle = ComboBoxStyle.DropDownList;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            string query = "Select representative from representative";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;


            DataAdapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            DataAdapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();

            DataAdapter.Fill(dataSet, "representative");

            con.Close();
            foreach (DataRow dr in dataSet.Tables["representative"].Rows)
            {


                names_box.Items.Add(dr["representative"].ToString());
            }
        //    names_box.DataSource= dataSet;
        }

        private void AddReport_Screen_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void AddReport_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
      
            string query = "UPDATE Report " +
              "SET Amount ='" + total_txt.Text.Trim() + "' ," +
              "Money_Back ='" + MoneyBack_txt.Text.Trim() + "' ," +
              "discount ='" + discount_txt.Text.Trim() + "' ," +
              "Given_Money ='" + givenMoney_txt.Text.Trim() + "' ," +
              "Line ='" + line_txt.Text.Trim() + "' ," +
                "Num_Of_Items ='" + NumOfItems_txt.Text.Trim() + "' ," +
              "Item_Back ='" + itemBack_txt.Text.Trim() + "' ," +
                "Delivery ='" + delivery_txt.Text.Trim() + "' ," +
              "Still ='" + still_txt.Text.Trim() + "' ," +
                "Cancel ='" + cancel_txt.Text.Trim() + "' ," +
              "Notes ='" + Notes_txt.Text.Trim() + "' " +
               "WHERE ID = '" + representative_id + "'";



            //    "'" + season + "')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MASSAGE_WIN FRM = new MASSAGE_WIN("تم تحديث بيانات القطعة بنجاح");
            FRM.ShowDialog(this);





            ShowReport_Screen frm = new ShowReport_Screen();
            //     frm.Item_dataGridView.DataSource=null;
            //   frm.Item_dataGridView.DataSource = dataSet.Tables["Item"];
            frm.Item_dataGridView.Refresh();
            frm.Item_dataGridView.Update();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(update_btn.Visible== false)
            {
                MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
                mainWindwo_Screen.Show();
                this.Hide();
            }
            else
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
          
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {

            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void AddReport_Btn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }
    }
}
