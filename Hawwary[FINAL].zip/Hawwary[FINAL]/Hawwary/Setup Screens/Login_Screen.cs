﻿using MissionsDB.MassageBox;
using MissionsDB.messagebox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hawwary
{
    public partial class Login_Screen : Form
    {
        public static Bitmap show_pass;
        public static Bitmap hide_pass;
        bool isAdmin = false;

        public bool show_pass_flag;
        public static string connection_string;
        SqlConnection con;
        SqlDataAdapter adapter;
        public Login_Screen()
        {
            InitializeComponent();

            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
        //    string fileName1 = "hide.png";
          //  string path1 = Path.Combine(Environment.CurrentDirectory, "Images", fileName1);

       //     string fileName2 = "eye.png";
            //string path2 = Path.Combine(Environment.CurrentDirectory, "Images", fileName2);
             show_pass = (Bitmap)Bitmap.FromFile(@"C:\Users\Z O M A\Source\Repos\Hawwary\Hawwary\bin\Debug\Images\hide.png");
            hide_pass = (Bitmap)Bitmap.FromFile(@"C:\Users\Z O M A\Source\Repos\Hawwary\Hawwary\bin\Debug\Images\eye.png");

        //    hide_pass = new Bitmap(path1);
          //  show_pass = new Bitmap(path2);
            show_pass_flag = true;
            pass_txt.UseSystemPasswordChar = true;
        }

    
        private void Login_Screen_Load(object sender, EventArgs e)
        {

        }
        private void user_login(string username_txt, string password_txt)
        {

         

         

        }
        private void admin_login()
        {

            MASSAGE_WIN FRM = new MASSAGE_WIN("مرحبا بالمشرف العام");
            FRM.ShowDialog(this);

            MainWindwo_Screen FRRM = new MainWindwo_Screen();
            FRRM.ADMIN_FLG = true;


            FRRM.Show();
            this.Hide();
        }

        private void Search_btn_Click(object sender, EventArgs e)
        {

            string username_txt = user_txt.Text.Trim();
            String password_txt = pass_txt.Text.Trim();

                if (username_txt == "" || password_txt == "")
            {
                ERROR_WIN FOORM = new ERROR_WIN(" يجب ادخال اسم المستخدم و كلمة المرور اولا");
                FOORM.ShowDialog(this);
                return;
            }
          
            adapter = new SqlDataAdapter();

  
            try
            {
                con.Open();


                string query = "select User_Name,Password from [dbo].[User] where User_Name ='" + username_txt +"'";
                SqlCommand command = new SqlCommand(query, con);
                command.CommandType = CommandType.Text;

                // Set the SqlDataAdapter's SelectCommand.
                adapter.SelectCommand = command;

                // Fill the DataSet.
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "User");
                isAdmin= true;
                con.Close();
                DataRow dataRow = dataSet.Tables["User"].Rows[0];
                string user = dataRow["User_Name"].ToString();
                string pass = dataRow["Password"].ToString();

                if (username_txt == "admin"&&password_txt==pass)
                {
                    admin_login();
             //       isAdmin= true;
                }
               else if(username_txt == user&& password_txt == pass)
                {
                      

                        MASSAGE_WIN FRM = new MASSAGE_WIN("مرحبا بالمستخدم");
                        //    int USER_ID = get_user_id();
                        FRM.ShowDialog(this);

                        MainWindwo_Screen FORM = new MainWindwo_Screen();

                        FORM.ADMIN_FLG = false;
                        //   FORM.user_id = USER_ID;
                        FORM.Show();
                        this.Hide();
                  
                }
                else
                {
                    ERROR_WIN FOORM = new ERROR_WIN(" اسم مستخدم او كلمة مرور غير صحيحة");
                    FOORM.ShowDialog(this);
                    return;
                }
            }
            
            catch
            {
                ERROR_WIN FOORM = new ERROR_WIN(" اسم مستخدم او كلمة مرور غير صحيحة");
                FOORM.ShowDialog(this);
                return;
            }

        

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.FlatStyle = FlatStyle.Flat;
            if (show_pass_flag)
            {
                button1.Image = show_pass;
                pass_txt.UseSystemPasswordChar = false;
            }
            else
            {
                button1.Image = hide_pass;
                pass_txt.UseSystemPasswordChar = true;
            }
            show_pass_flag = !show_pass_flag;
        }

        private void user_txt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
