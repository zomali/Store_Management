﻿using Hawwary.Add_Screens;
using MissionsDB.MassageBox;
using MissionsDB.messagebox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hawwary
{
    public partial class Register_Screen : Form
    {
        String query;
        String where;

        public static Bitmap show_pass;
        public static Bitmap hide_pass;
        public bool show_pass_flag;

        public string MyPage;
        SqlConnection con;
        SqlDataAdapter adapter;
        string connection_string;
        public Register_Screen()
        {
            InitializeComponent();
            show_pass = (Bitmap)Bitmap.FromFile(@"C:\Users\Z O M A\Source\Repos\Hawwary\Hawwary\bin\Debug\Images\hide.png");
            hide_pass = (Bitmap)Bitmap.FromFile(@"C:\Users\Z O M A\Source\Repos\Hawwary\Hawwary\bin\Debug\Images\eye.png");

            //    hide_pass = new Bitmap(path1);
            //  show_pass = new Bitmap(path2);
            show_pass_flag = true;
            pass_txt.UseSystemPasswordChar = true;

          
            MyPage = "Register";
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
            query = "SELECT ID," +
                    "Name," +
                    "Amount," +
                    "Money_Back," +
                    "discount," +
                    "Given_Money," +
                    "Total_Amount" +

                    " FROM Report";
        }

        private void Login_Btn_Click(object sender, EventArgs e)
        {
           

            string username_txt = user_txt.Text;
            
            String password_txt = pass_txt.Text;

            // checks on inputs
            if (username_txt.Length < 3)
            {

                ERROR_WIN FOORM = new ERROR_WIN("اسم المستخدم يجب الا يقل عن 3 حروف");
                FOORM.ShowDialog(this);
                return;

            }

            if (password_txt.Length < 5)
            {

                ERROR_WIN FOORM = new ERROR_WIN("كلمة المرور يجب الا تقل عن 5 حروف");
                FOORM.ShowDialog(this);
                return;

            }
            // insert in case of successfull
            con.Open();
            SqlCommand command = new SqlCommand("insert into [dbo].[User]" +
                " (USER_NAME," +
                "PASSWORD" +
                ") " +
                 
                "values " +
                "(" +
                "'" + username_txt +
                "','" + password_txt +
                "');", con);


         

            command.ExecuteNonQuery();
            con.Close();
            MASSAGE_WIN FRM = new MASSAGE_WIN("تم إضافة المستخدم بنجاح");
            FRM.ShowDialog(this);
          //  name_txt.Text = "";
            pass_txt.Text = "";
            user_txt.Text = "";
          //  NEW_BTN.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String Repersentative_txt = name.Text;



            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            string query = "Select representative from representative";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;


            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();

            adapter.Fill(dataSet, "representative");

            con.Close();


            foreach (DataRow dr in dataSet.Tables["representative"].Rows)
            {
                if(Repersentative_txt== dr["representative"].ToString())
                {
                    ERROR_WIN FOORM = new ERROR_WIN("هذا المندوب موجود بالفعل");
                    FOORM.ShowDialog(this);
                    return;
                }

               // names_box.Items.Add(dr["representative"].ToString());
            }




            try
            {

                con.Open();
                command = new SqlCommand("insert into representative" +
                   " (representative) " +
                 "values " +
                   "(" +
                   "'" + Repersentative_txt +
                   "');", con);


                command.ExecuteNonQuery();
                con.Close();
                MASSAGE_WIN FRM = new MASSAGE_WIN("تم إضافة المندوب بنجاح");
                FRM.ShowDialog(this);
                //  name_txt.Text = "";
                name.Text = "";
            }
            catch
            {
                ERROR_WIN FOORM = new ERROR_WIN("خطأ في إضافة المندوب");
                FOORM.ShowDialog(this);
                return;
            }
       

        }

        private void Register_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }
        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }
        private void إضافةمستخدماومندوبجديدToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Register_Screen_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.FlatStyle = FlatStyle.Flat;
            if (show_pass_flag)
            {
                button1.Image = show_pass;
                pass_txt.UseSystemPasswordChar = false;
            }
            else
            {
                button1.Image = hide_pass;
                pass_txt.UseSystemPasswordChar = true;
            }
            show_pass_flag = !show_pass_flag;
        }
    }
}
