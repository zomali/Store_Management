﻿namespace Hawwary
{
    partial class Register_Screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ToolStripDropDownButton Setting_Btn;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register_Screen));
            this.ADD_Representative = new System.Windows.Forms.ToolStripMenuItem();
            this.Add_User = new System.Windows.Forms.ToolStripMenuItem();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Register_Btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.pass_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.user_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.name = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Add_Client_btn = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.MainBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel11 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel12 = new System.Windows.Forms.ToolStripLabel();
            this.AddPaymentBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.ClientSearch = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.AddClientBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.StoreDetails = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.AddItemBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel10 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel13 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel14 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel15 = new System.Windows.Forms.ToolStripLabel();
            this.showBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel16 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel17 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel18 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            Setting_Btn = new System.Windows.Forms.ToolStripDropDownButton();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Add_Client_btn.SuspendLayout();
            this.SuspendLayout();
            // 
            // Setting_Btn
            // 
            Setting_Btn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            Setting_Btn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ADD_Representative,
            this.Add_User});
            Setting_Btn.Image = ((System.Drawing.Image)(resources.GetObject("Setting_Btn.Image")));
            Setting_Btn.ImageTransparentColor = System.Drawing.Color.Magenta;
            Setting_Btn.Name = "Setting_Btn";
            Setting_Btn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            Setting_Btn.Size = new System.Drawing.Size(159, 29);
            Setting_Btn.Text = "الإعدادات";
            Setting_Btn.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            Setting_Btn.Click += new System.EventHandler(this.toolStripDropDownButton1_Click);
            // 
            // ADD_Representative
            // 
            this.ADD_Representative.Name = "ADD_Representative";
            this.ADD_Representative.Size = new System.Drawing.Size(328, 30);
            this.ADD_Representative.Text = "إضافة مستخدم او مندوب جديد";
            this.ADD_Representative.Click += new System.EventHandler(this.ADD_Representative_Click);
            // 
            // Add_User
            // 
            this.Add_User.Name = "Add_User";
            this.Add_User.Size = new System.Drawing.Size(328, 30);
            this.Add_User.Text = "تغيير كلمة السر";
            this.Add_User.Click += new System.EventHandler(this.Add_User_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(666, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(298, 54);
            this.label6.TabIndex = 47;
            this.label6.Text = "Hawwary Online Store";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(480, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(120, 108);
            this.panel1.TabIndex = 46;
            // 
            // Register_Btn
            // 
            this.Register_Btn.BackColor = System.Drawing.Color.Chocolate;
            this.Register_Btn.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Register_Btn.Location = new System.Drawing.Point(516, 326);
            this.Register_Btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Register_Btn.Name = "Register_Btn";
            this.Register_Btn.Size = new System.Drawing.Size(235, 70);
            this.Register_Btn.TabIndex = 52;
            this.Register_Btn.Text = "إضافة مستخدم";
            this.Register_Btn.UseVisualStyleBackColor = false;
            this.Register_Btn.Click += new System.EventHandler(this.Login_Btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(957, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 34);
            this.label2.TabIndex = 51;
            this.label2.Text = "كلمة السر";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Window;
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.pass_txt);
            this.panel4.Location = new System.Drawing.Point(311, 253);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(597, 55);
            this.panel4.TabIndex = 50;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(19, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(49, 32);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pass_txt
            // 
            this.pass_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pass_txt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pass_txt.ForeColor = System.Drawing.Color.Chocolate;
            this.pass_txt.Location = new System.Drawing.Point(79, 16);
            this.pass_txt.Name = "pass_txt";
            this.pass_txt.Size = new System.Drawing.Size(497, 25);
            this.pass_txt.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(923, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 34);
            this.label1.TabIndex = 49;
            this.label1.Text = "أسم المستخدم";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.Controls.Add(this.user_txt);
            this.panel3.Location = new System.Drawing.Point(311, 173);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(597, 55);
            this.panel3.TabIndex = 48;
            // 
            // user_txt
            // 
            this.user_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.user_txt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.user_txt.ForeColor = System.Drawing.Color.Chocolate;
            this.user_txt.Location = new System.Drawing.Point(35, 16);
            this.user_txt.Name = "user_txt";
            this.user_txt.Size = new System.Drawing.Size(541, 25);
            this.user_txt.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(939, 631);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 34);
            this.label3.TabIndex = 54;
            this.label3.Text = "أسم المندوب";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.name);
            this.panel2.Location = new System.Drawing.Point(311, 615);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(597, 55);
            this.panel2.TabIndex = 53;
            // 
            // name
            // 
            this.name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.name.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.name.ForeColor = System.Drawing.Color.Chocolate;
            this.name.Location = new System.Drawing.Point(35, 16);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(541, 25);
            this.name.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Chocolate;
            this.button2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(134, 615);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(149, 55);
            this.button2.TabIndex = 55;
            this.button2.Text = "إضافة مندوب";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(50, 30);
            this.button3.Name = "button3";
            this.button3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button3.Size = new System.Drawing.Size(70, 70);
            this.button3.TabIndex = 56;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Add_Client_btn
            // 
            this.Add_Client_btn.BackColor = System.Drawing.Color.Tan;
            this.Add_Client_btn.Dock = System.Windows.Forms.DockStyle.Right;
            this.Add_Client_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add_Client_btn.GripMargin = new System.Windows.Forms.Padding(0);
            this.Add_Client_btn.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Add_Client_btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.MainBtn,
            this.toolStripLabel11,
            this.toolStripSeparator6,
            this.toolStripLabel12,
            this.AddPaymentBtn,
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.toolStripLabel6,
            this.ClientSearch,
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripLabel7,
            this.AddClientBtn,
            this.toolStripLabel3,
            this.toolStripSeparator3,
            this.toolStripLabel8,
            this.StoreDetails,
            this.toolStripLabel5,
            this.toolStripSeparator4,
            this.toolStripLabel9,
            this.AddItemBtn,
            this.toolStripLabel10,
            this.toolStripSeparator5,
            this.toolStripLabel13,
            this.toolStripButton1,
            this.toolStripLabel14,
            this.toolStripSeparator7,
            this.toolStripLabel15,
            this.showBtn,
            this.toolStripLabel16,
            this.toolStripSeparator8,
            this.toolStripLabel17,
            Setting_Btn,
            this.toolStripLabel18,
            this.toolStripSeparator9});
            this.Add_Client_btn.Location = new System.Drawing.Point(1322, 0);
            this.Add_Client_btn.Name = "Add_Client_btn";
            this.Add_Client_btn.Padding = new System.Windows.Forms.Padding(0);
            this.Add_Client_btn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Add_Client_btn.Size = new System.Drawing.Size(160, 753);
            this.Add_Client_btn.Stretch = true;
            this.Add_Client_btn.TabIndex = 88;
            this.Add_Client_btn.Text = "الشاشة الرئيسية";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.AutoSize = false;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripLabel4.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel4.Text = " ";
            // 
            // MainBtn
            // 
            this.MainBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MainBtn.Image = ((System.Drawing.Image)(resources.GetObject("MainBtn.Image")));
            this.MainBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainBtn.Name = "MainBtn";
            this.MainBtn.Size = new System.Drawing.Size(159, 29);
            this.MainBtn.Text = "الشاشة الرئيسية";
            this.MainBtn.Click += new System.EventHandler(this.MainBtn_Click);
            // 
            // toolStripLabel11
            // 
            this.toolStripLabel11.AutoSize = false;
            this.toolStripLabel11.Enabled = false;
            this.toolStripLabel11.Name = "toolStripLabel11";
            this.toolStripLabel11.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel11.Text = " ";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel12
            // 
            this.toolStripLabel12.AutoSize = false;
            this.toolStripLabel12.Enabled = false;
            this.toolStripLabel12.Name = "toolStripLabel12";
            this.toolStripLabel12.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel12.Text = " ";
            // 
            // AddPaymentBtn
            // 
            this.AddPaymentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPaymentBtn.Image = ((System.Drawing.Image)(resources.GetObject("AddPaymentBtn.Image")));
            this.AddPaymentBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPaymentBtn.Name = "AddPaymentBtn";
            this.AddPaymentBtn.Size = new System.Drawing.Size(159, 29);
            this.AddPaymentBtn.Text = "عملية شراء جديدة";
            this.AddPaymentBtn.Click += new System.EventHandler(this.AddPaymentBtn_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.AutoSize = false;
            this.toolStripLabel1.Enabled = false;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel1.Text = "          ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.AutoSize = false;
            this.toolStripLabel6.Enabled = false;
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel6.Text = " ";
            // 
            // ClientSearch
            // 
            this.ClientSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ClientSearch.Image = ((System.Drawing.Image)(resources.GetObject("ClientSearch.Image")));
            this.ClientSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClientSearch.Name = "ClientSearch";
            this.ClientSearch.Size = new System.Drawing.Size(159, 29);
            this.ClientSearch.Text = "البحث عن عميل";
            this.ClientSearch.Click += new System.EventHandler(this.ClientSearch_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.AutoSize = false;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel2.Text = "   ";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.AutoSize = false;
            this.toolStripLabel7.Enabled = false;
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel7.Text = " ";
            // 
            // AddClientBtn
            // 
            this.AddClientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddClientBtn.Image = ((System.Drawing.Image)(resources.GetObject("AddClientBtn.Image")));
            this.AddClientBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddClientBtn.Name = "AddClientBtn";
            this.AddClientBtn.Size = new System.Drawing.Size(159, 29);
            this.AddClientBtn.Text = "إضافة عميل";
            this.AddClientBtn.Click += new System.EventHandler(this.AddClientBtn_Click);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.AutoSize = false;
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel3.Text = "  ";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.AutoSize = false;
            this.toolStripLabel8.Enabled = false;
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel8.Text = " ";
            // 
            // StoreDetails
            // 
            this.StoreDetails.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StoreDetails.Image = ((System.Drawing.Image)(resources.GetObject("StoreDetails.Image")));
            this.StoreDetails.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StoreDetails.Name = "StoreDetails";
            this.StoreDetails.Size = new System.Drawing.Size(159, 29);
            this.StoreDetails.Text = "عرض المخزن";
            this.StoreDetails.Click += new System.EventHandler(this.StoreDetails_Click);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.AutoSize = false;
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel5.Text = " ";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.AutoSize = false;
            this.toolStripLabel9.Enabled = false;
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel9.Text = " ";
            // 
            // AddItemBtn
            // 
            this.AddItemBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddItemBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddItemBtn.Name = "AddItemBtn";
            this.AddItemBtn.Size = new System.Drawing.Size(159, 29);
            this.AddItemBtn.Text = "إضافة قطعة جديدة";
            this.AddItemBtn.Click += new System.EventHandler(this.AddItemBtn_Click);
            // 
            // toolStripLabel10
            // 
            this.toolStripLabel10.AutoSize = false;
            this.toolStripLabel10.Enabled = false;
            this.toolStripLabel10.Name = "toolStripLabel10";
            this.toolStripLabel10.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel10.Text = " ";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel13
            // 
            this.toolStripLabel13.AutoSize = false;
            this.toolStripLabel13.Enabled = false;
            this.toolStripLabel13.Name = "toolStripLabel13";
            this.toolStripLabel13.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel13.Text = " ";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(159, 29);
            this.toolStripButton1.Text = "إضافة تقرير";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripLabel14
            // 
            this.toolStripLabel14.AutoSize = false;
            this.toolStripLabel14.Enabled = false;
            this.toolStripLabel14.Name = "toolStripLabel14";
            this.toolStripLabel14.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel14.Text = " ";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel15
            // 
            this.toolStripLabel15.AutoSize = false;
            this.toolStripLabel15.Enabled = false;
            this.toolStripLabel15.Name = "toolStripLabel15";
            this.toolStripLabel15.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel15.Text = " ";
            // 
            // showBtn
            // 
            this.showBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.showBtn.Image = ((System.Drawing.Image)(resources.GetObject("showBtn.Image")));
            this.showBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.showBtn.Name = "showBtn";
            this.showBtn.Size = new System.Drawing.Size(159, 29);
            this.showBtn.Text = "عرض التقارير";
            this.showBtn.Click += new System.EventHandler(this.showBtn_Click);
            // 
            // toolStripLabel16
            // 
            this.toolStripLabel16.AutoSize = false;
            this.toolStripLabel16.Enabled = false;
            this.toolStripLabel16.Name = "toolStripLabel16";
            this.toolStripLabel16.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel16.Text = " ";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel17
            // 
            this.toolStripLabel17.AutoSize = false;
            this.toolStripLabel17.Enabled = false;
            this.toolStripLabel17.Name = "toolStripLabel17";
            this.toolStripLabel17.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel17.Text = " ";
            // 
            // toolStripLabel18
            // 
            this.toolStripLabel18.AutoSize = false;
            this.toolStripLabel18.Enabled = false;
            this.toolStripLabel18.Name = "toolStripLabel18";
            this.toolStripLabel18.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel18.Text = " ";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(159, 6);
            // 
            // Register_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.Add_Client_btn);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Register_Btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Register_Screen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "إضافة مستخدم أو مندوب جديد";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Register_Screen_FormClosing);
            this.Load += new System.EventHandler(this.Register_Screen_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Add_Client_btn.ResumeLayout(false);
            this.Add_Client_btn.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label6;
        private Panel panel1;
        private Button Register_Btn;
        private Label label2;
        private Panel panel4;
        private Button button1;
        private TextBox pass_txt;
        private Label label1;
        private Panel panel3;
        private TextBox user_txt;
        private Label label3;
        private Panel panel2;
        private TextBox name;
        private Button button2;
        private Button button3;
        private ToolStrip Add_Client_btn;
        private ToolStripLabel toolStripLabel4;
        private ToolStripButton MainBtn;
        private ToolStripLabel toolStripLabel11;
        private ToolStripSeparator toolStripSeparator6;
        private ToolStripLabel toolStripLabel12;
        private ToolStripButton AddPaymentBtn;
        private ToolStripLabel toolStripLabel1;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripLabel toolStripLabel6;
        private ToolStripButton ClientSearch;
        private ToolStripLabel toolStripLabel2;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripLabel toolStripLabel7;
        public ToolStripButton AddClientBtn;
        private ToolStripLabel toolStripLabel3;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripLabel toolStripLabel8;
        private ToolStripButton StoreDetails;
        private ToolStripLabel toolStripLabel5;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripLabel toolStripLabel9;
        private ToolStripButton AddItemBtn;
        private ToolStripLabel toolStripLabel10;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripLabel toolStripLabel13;
        private ToolStripButton toolStripButton1;
        private ToolStripLabel toolStripLabel14;
        private ToolStripSeparator toolStripSeparator7;
        private ToolStripLabel toolStripLabel15;
        private ToolStripButton showBtn;
        private ToolStripLabel toolStripLabel16;
        private ToolStripSeparator toolStripSeparator8;
        private ToolStripLabel toolStripLabel17;
        private ToolStripMenuItem ADD_Representative;
        private ToolStripMenuItem Add_User;
        private ToolStripLabel toolStripLabel18;
        private ToolStripSeparator toolStripSeparator9;
    }
}