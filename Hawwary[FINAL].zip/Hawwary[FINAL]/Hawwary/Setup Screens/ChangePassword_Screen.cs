﻿using Hawwary.Add_Screens;
using MissionsDB.MassageBox;
using MissionsDB.messagebox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Hawwary
{
    public partial class ChangePassword_Screen : Form
    {
        public static Bitmap show_pass;
        public static Bitmap hide_pass;
        public bool show_pass_flag;
        public string MyPage;

        public static string connection_string;
        SqlConnection con;
        SqlDataAdapter adapter;
        public ChangePassword_Screen()
        {
            InitializeComponent();
            show_pass = (Bitmap)Bitmap.FromFile(@"C:\Users\Z O M A\Source\Repos\Hawwary\Hawwary\bin\Debug\Images\hide.png");
            hide_pass = (Bitmap)Bitmap.FromFile(@"C:\Users\Z O M A\Source\Repos\Hawwary\Hawwary\bin\Debug\Images\eye.png");
            Old_Pass_txt.UseSystemPasswordChar = true;
            New_pass_txt.UseSystemPasswordChar = true;
            Re_New_pass_txt.UseSystemPasswordChar = true;


            MyPage = "ChangePassword";
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
        }

        private void Login_Btn_Click(object sender, EventArgs e)
        {
            try
            {

                if (New_pass_txt.Text.Trim()!= Re_New_pass_txt.Text.Trim())
                {
                    ERROR_WIN FoRM = new ERROR_WIN("كلمةالسر الجديدة غير مطابقة");
                    FoRM.ShowDialog(this);
                    return;
                }

                //if (New_pass_txt.Text.Length<5)
                //{
                //    ERROR_WIN FoRM = new ERROR_WIN("يجب الا تقل كلمة المرور عن 5 حروف");
                //    FoRM.ShowDialog(this);
                //}


                if (change_password()) {

                    MASSAGE_WIN FRM = new MASSAGE_WIN("تم تغيير كلمة المرور بنجاح");
                    FRM.ShowDialog(this);
                }
                else
                {
                    MASSAGE_WIN FRM = new MASSAGE_WIN("خطأ في تغيير كلمة السر");
                    FRM.ShowDialog(this);
                }
              
            }
            catch {
                MASSAGE_WIN FRM = new MASSAGE_WIN("خطأ في تغيير كلمة السر");
                FRM.ShowDialog(this);
            }
        }

        private void ChangePassword_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }
        private bool change_password()
        {
          string  query1 = "SELECT Password" +
                       
                        " FROM [dbo].[User] " +
                        "Where User_Name= '" + "admin" + "'";
            SqlCommand command = new SqlCommand(query1, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "User");
            DataRow dataRow = dataSet.Tables["User"].Rows[0];
            DataSet data = new DataSet();
            // data = <DataSet>( dataRow["Name"]);
        

            string Password = dataRow["Password"].ToString();
          if(Old_Pass_txt.Text.Trim()!=Password)
                return false;


            con.Open();
            string query = "UPDATE [dbo].[User] SET PASSWORD  = '" + New_pass_txt.Text.Trim() + "' where User_Name= '" + "admin" + "' and Password='" + Old_Pass_txt.Text.Trim() + "'  ";
             command = new SqlCommand(query, con);
            command.ExecuteNonQuery();
            con.Close();
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }

        private void ChangePassword_Screen_Load(object sender, EventArgs e)
        {
     
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.FlatStyle = FlatStyle.Flat;
            if (show_pass_flag)
            {
                button2.Image = show_pass;
                Old_Pass_txt.UseSystemPasswordChar = false;
                New_pass_txt.UseSystemPasswordChar = false;
                Re_New_pass_txt.UseSystemPasswordChar = false;

            }
            else
            {
                button2.Image = hide_pass;
                Old_Pass_txt.UseSystemPasswordChar = true;
                New_pass_txt.UseSystemPasswordChar = true;
                Re_New_pass_txt.UseSystemPasswordChar = true;
            }
            show_pass_flag = !show_pass_flag;
        }
    }
}
