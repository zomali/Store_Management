﻿namespace Hawwary
{
    partial class MainWindwo_Screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindwo_Screen));
            this.ADD_Representative = new System.Windows.Forms.ToolStripMenuItem();
            this.Add_User = new System.Windows.Forms.ToolStripMenuItem();
            this.AddClientBtn = new System.Windows.Forms.ToolStripButton();
            this.AddItemBtn = new System.Windows.Forms.ToolStripButton();
            this.AddPaymentBtn = new System.Windows.Forms.ToolStripButton();
            this.ClientSearch = new System.Windows.Forms.ToolStripButton();
            this.StoreDetails = new System.Windows.Forms.ToolStripButton();
            this.Add_Client_btn = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.MainBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel11 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel12 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel10 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel13 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel14 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel15 = new System.Windows.Forms.ToolStripLabel();
            this.showBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel16 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel17 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel18 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.Add_Client_btn.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripDropDownButton1
            // 
            toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ADD_Representative,
            this.Add_User});
            toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            toolStripDropDownButton1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            toolStripDropDownButton1.Size = new System.Drawing.Size(159, 29);
            toolStripDropDownButton1.Text = "الإعدادات";
            toolStripDropDownButton1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            toolStripDropDownButton1.Click += new System.EventHandler(this.toolStripDropDownButton1_Click);
            // 
            // ADD_Representative
            // 
            this.ADD_Representative.Name = "ADD_Representative";
            this.ADD_Representative.Size = new System.Drawing.Size(328, 30);
            this.ADD_Representative.Text = "إضافة مستخدم او مندوب جديد";
            this.ADD_Representative.Click += new System.EventHandler(this.ADD_Representative_Click);
            // 
            // Add_User
            // 
            this.Add_User.Name = "Add_User";
            this.Add_User.Size = new System.Drawing.Size(328, 30);
            this.Add_User.Text = "تغيير كلمة السر";
            this.Add_User.Click += new System.EventHandler(this.Add_User_Click);
            // 
            // AddClientBtn
            // 
            this.AddClientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddClientBtn.Image = ((System.Drawing.Image)(resources.GetObject("AddClientBtn.Image")));
            this.AddClientBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddClientBtn.Name = "AddClientBtn";
            this.AddClientBtn.Size = new System.Drawing.Size(159, 29);
            this.AddClientBtn.Text = "إضافة عميل";
            this.AddClientBtn.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // AddItemBtn
            // 
            this.AddItemBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddItemBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddItemBtn.Name = "AddItemBtn";
            this.AddItemBtn.Size = new System.Drawing.Size(159, 29);
            this.AddItemBtn.Text = "إضافة قطعة جديدة";
            this.AddItemBtn.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // AddPaymentBtn
            // 
            this.AddPaymentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPaymentBtn.Image = ((System.Drawing.Image)(resources.GetObject("AddPaymentBtn.Image")));
            this.AddPaymentBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPaymentBtn.Name = "AddPaymentBtn";
            this.AddPaymentBtn.Size = new System.Drawing.Size(159, 29);
            this.AddPaymentBtn.Text = "عملية شراء جديدة";
            this.AddPaymentBtn.Click += new System.EventHandler(this.AddPaymentBtn_Click);
            // 
            // ClientSearch
            // 
            this.ClientSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ClientSearch.Image = ((System.Drawing.Image)(resources.GetObject("ClientSearch.Image")));
            this.ClientSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClientSearch.Name = "ClientSearch";
            this.ClientSearch.Size = new System.Drawing.Size(159, 29);
            this.ClientSearch.Text = "البحث عن عميل";
            this.ClientSearch.Click += new System.EventHandler(this.ClientSearch_Click);
            // 
            // StoreDetails
            // 
            this.StoreDetails.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StoreDetails.Image = ((System.Drawing.Image)(resources.GetObject("StoreDetails.Image")));
            this.StoreDetails.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StoreDetails.Name = "StoreDetails";
            this.StoreDetails.Size = new System.Drawing.Size(159, 29);
            this.StoreDetails.Text = "عرض المخزن";
            this.StoreDetails.Click += new System.EventHandler(this.StoreDetails_Click);
            // 
            // Add_Client_btn
            // 
            this.Add_Client_btn.BackColor = System.Drawing.Color.Tan;
            this.Add_Client_btn.Dock = System.Windows.Forms.DockStyle.Right;
            this.Add_Client_btn.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add_Client_btn.GripMargin = new System.Windows.Forms.Padding(0);
            this.Add_Client_btn.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Add_Client_btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.MainBtn,
            this.toolStripLabel11,
            this.toolStripSeparator6,
            this.toolStripLabel12,
            this.AddPaymentBtn,
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.toolStripLabel6,
            this.ClientSearch,
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripLabel7,
            this.AddClientBtn,
            this.toolStripLabel3,
            this.toolStripSeparator3,
            this.toolStripLabel8,
            this.StoreDetails,
            this.toolStripLabel5,
            this.toolStripSeparator4,
            this.toolStripLabel9,
            this.AddItemBtn,
            this.toolStripLabel10,
            this.toolStripSeparator5,
            this.toolStripLabel13,
            this.toolStripButton1,
            this.toolStripLabel14,
            this.toolStripSeparator7,
            this.toolStripLabel15,
            this.showBtn,
            this.toolStripLabel16,
            this.toolStripSeparator8,
            this.toolStripLabel17,
            toolStripDropDownButton1,
            this.toolStripLabel18,
            this.toolStripSeparator9});
            this.Add_Client_btn.Location = new System.Drawing.Point(1322, 0);
            this.Add_Client_btn.Name = "Add_Client_btn";
            this.Add_Client_btn.Padding = new System.Windows.Forms.Padding(0);
            this.Add_Client_btn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Add_Client_btn.Size = new System.Drawing.Size(160, 753);
            this.Add_Client_btn.Stretch = true;
            this.Add_Client_btn.TabIndex = 0;
            this.Add_Client_btn.Text = "الشاشة الرئيسية";
            this.Add_Client_btn.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.Add_Client_btn_ItemClicked);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.AutoSize = false;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripLabel4.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel4.Text = " ";
            // 
            // MainBtn
            // 
            this.MainBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MainBtn.Image = ((System.Drawing.Image)(resources.GetObject("MainBtn.Image")));
            this.MainBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainBtn.Name = "MainBtn";
            this.MainBtn.Size = new System.Drawing.Size(159, 29);
            this.MainBtn.Text = "الشاشة الرئيسية";
            this.MainBtn.Click += new System.EventHandler(this.MainBtn_Click);
            // 
            // toolStripLabel11
            // 
            this.toolStripLabel11.AutoSize = false;
            this.toolStripLabel11.Enabled = false;
            this.toolStripLabel11.Name = "toolStripLabel11";
            this.toolStripLabel11.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel11.Text = " ";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel12
            // 
            this.toolStripLabel12.AutoSize = false;
            this.toolStripLabel12.Enabled = false;
            this.toolStripLabel12.Name = "toolStripLabel12";
            this.toolStripLabel12.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel12.Text = " ";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.AutoSize = false;
            this.toolStripLabel1.Enabled = false;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel1.Text = "          ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.AutoSize = false;
            this.toolStripLabel6.Enabled = false;
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel6.Text = " ";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.AutoSize = false;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel2.Text = "   ";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.AutoSize = false;
            this.toolStripLabel7.Enabled = false;
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel7.Text = " ";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.AutoSize = false;
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel3.Text = "  ";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.AutoSize = false;
            this.toolStripLabel8.Enabled = false;
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel8.Text = " ";
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.AutoSize = false;
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel5.Text = " ";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.AutoSize = false;
            this.toolStripLabel9.Enabled = false;
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel9.Text = " ";
            // 
            // toolStripLabel10
            // 
            this.toolStripLabel10.AutoSize = false;
            this.toolStripLabel10.Enabled = false;
            this.toolStripLabel10.Name = "toolStripLabel10";
            this.toolStripLabel10.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel10.Text = " ";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel13
            // 
            this.toolStripLabel13.AutoSize = false;
            this.toolStripLabel13.Enabled = false;
            this.toolStripLabel13.Name = "toolStripLabel13";
            this.toolStripLabel13.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel13.Text = " ";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(159, 29);
            this.toolStripButton1.Text = "إضافة تقرير";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // toolStripLabel14
            // 
            this.toolStripLabel14.AutoSize = false;
            this.toolStripLabel14.Enabled = false;
            this.toolStripLabel14.Name = "toolStripLabel14";
            this.toolStripLabel14.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel14.Text = " ";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(159, 6);
            // 
            // toolStripLabel15
            // 
            this.toolStripLabel15.AutoSize = false;
            this.toolStripLabel15.Enabled = false;
            this.toolStripLabel15.Name = "toolStripLabel15";
            this.toolStripLabel15.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel15.Text = " ";
            this.toolStripLabel15.Click += new System.EventHandler(this.toolStripLabel15_Click);
            // 
            // showBtn
            // 
            this.showBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.showBtn.Image = ((System.Drawing.Image)(resources.GetObject("showBtn.Image")));
            this.showBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.showBtn.Name = "showBtn";
            this.showBtn.Size = new System.Drawing.Size(159, 29);
            this.showBtn.Text = "عرض التقارير";
            this.showBtn.Click += new System.EventHandler(this.toolStripButton2_Click_1);
            // 
            // toolStripLabel16
            // 
            this.toolStripLabel16.AutoSize = false;
            this.toolStripLabel16.Enabled = false;
            this.toolStripLabel16.Name = "toolStripLabel16";
            this.toolStripLabel16.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel16.Text = " ";
            this.toolStripLabel16.Click += new System.EventHandler(this.toolStripLabel16_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(159, 6);
            this.toolStripSeparator8.Click += new System.EventHandler(this.toolStripSeparator8_Click);
            // 
            // toolStripLabel17
            // 
            this.toolStripLabel17.AutoSize = false;
            this.toolStripLabel17.Enabled = false;
            this.toolStripLabel17.Name = "toolStripLabel17";
            this.toolStripLabel17.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel17.Text = " ";
            // 
            // toolStripLabel18
            // 
            this.toolStripLabel18.AutoSize = false;
            this.toolStripLabel18.Enabled = false;
            this.toolStripLabel18.Name = "toolStripLabel18";
            this.toolStripLabel18.Size = new System.Drawing.Size(159, 15);
            this.toolStripLabel18.Text = " ";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(159, 6);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(3, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(602, 54);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hawwary Online Store";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(430, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(609, 125);
            this.panel1.TabIndex = 2;
            // 
            // MainWindwo_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Add_Client_btn);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1500, 800);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1500, 800);
            this.Name = "MainWindwo_Screen";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "الشاشة الرئيسية";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainWindwo_Screen_FormClosing);
            this.Load += new System.EventHandler(this.MainWindwo_Screen_Load);
            this.Add_Client_btn.ResumeLayout(false);
            this.Add_Client_btn.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ToolStripButton AddItemBtn;
        private ToolStripButton AddPaymentBtn;
        private ToolStripButton ClientSearch;
        private ToolStripButton StoreDetails;
        private ToolStrip Add_Client_btn;
        private ToolStripLabel toolStripLabel1;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripLabel toolStripLabel2;
        private ToolStripLabel toolStripLabel3;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripLabel toolStripLabel4;
        private ToolStripLabel toolStripLabel6;
        private ToolStripLabel toolStripLabel7;
        private ToolStripLabel toolStripLabel5;
        private ToolStripLabel toolStripLabel8;
        private ToolStripLabel toolStripLabel9;
        private ToolStripLabel toolStripLabel10;
        private ToolStripSeparator toolStripSeparator5;
        private Label label1;
        private ToolStripLabel toolStripLabel11;
        private ToolStripSeparator toolStripSeparator6;
        private ToolStripLabel toolStripLabel12;
        public ToolStripButton AddClientBtn;
        private ToolStripButton MainBtn;
        private Panel panel1;
        private ToolStripLabel toolStripLabel13;
        private ToolStripButton toolStripButton1;
        private ToolStripLabel toolStripLabel14;
        private ToolStripSeparator toolStripSeparator7;
        private ToolStripLabel toolStripLabel15;
        private ToolStripButton showBtn;
        private ToolStripLabel toolStripLabel16;
        private ToolStripSeparator toolStripSeparator8;
        private ToolStripLabel toolStripLabel17;
        private ToolStripDropDownButton toolStripDropDownButton1;
        private ToolStripLabel toolStripLabel18;
        private ToolStripSeparator toolStripSeparator9;
        private ToolStripMenuItem ADD_Representative;
        private ToolStripMenuItem Add_User;
    }
}