﻿using Hawwary.Add_Screens;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hawwary
{
    public partial class MainWindwo_Screen : Form
    {
        public string MyPage;
        public bool ADMIN_FLG=false;
        public PaymentDetails_Screen paymentDetails_Screen = new PaymentDetails_Screen();
        public MainWindwo_Screen()
        {
            InitializeComponent();
             MyPage = "Main";
        }

        private void toolStripButton2_Click(object sender, EventArgs e)

        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;
                this.Hide();
                addItem_Screen.Show();
                 
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();
                this.Hide();
                addClient_Screen.Show();
            
        }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();
                this.Hide();
                addPayment_Screen.Show();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                if (ADMIN_FLG == true)
                {

                clientSearch_Screen.ADMIN_FLG= true;
                }
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();
                this.Hide();
                storeDetails_Screen.Show();
            }
        }

        private void MainWindwo_Screen_Load(object sender, EventArgs e)
        {
            if(ADMIN_FLG==false)
            {
                AddPaymentBtn.Enabled= false;
                AddClientBtn.Enabled= false;
                AddPaymentBtn.Enabled= false;
                StoreDetails.Enabled= false;
                AddItemBtn.Enabled= false;
                showBtn.Enabled= false;
                toolStripButton1.Enabled = false;
                ADD_Representative.Enabled= false;
                Add_User.Enabled= false;

            }
           
         //   if (MyPage == "Main")
         //   {
                MainBtn.BackColor= Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            MainBtn.Font=new Font ("Segoe UI Semibold",14,FontStyle.Bold);
            //  MainBtn.Font.Size= true;
            //   }

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton10_Click(object sender, EventArgs e)
        {

        }

        private void Add_Client_btn_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void StoreDetails_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripButton5_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if(MyPage != "Main")
            {
                MainWindwo_Screen form= new MainWindwo_Screen();
                form.Show();
                this.Close();
            }

        }

        private void MainWindwo_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void toolStripLabel15_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripLabel16_Click(object sender, EventArgs e)
        {

        }

        private void toolStripSeparator8_Click(object sender, EventArgs e)
        {

        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register_Screen")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }

        private void Change_Password_Btn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addReport_Screen = new AddReport_Screen();
                addReport_Screen.Show();
                this.Hide();
            }
        }
    }
}
