﻿using Hawwary.Add_Screens;
using MissionsDB.messagebox;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hawwary
{
    public partial class StoreDetails_Screen : Form
    {
        String query;
        String where;

        public string MyPage;
        SqlConnection con;
        SqlDataAdapter adapter;
        string connection_string;
        public StoreDetails_Screen()
        {
            InitializeComponent();
            MyPage= "StoreDetails";
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
            query = "SELECT ID," +
                    "Brand," +
                    "Type," +
                    "gender," +
                    "Season," +
                    "Price," +
                    "Store_Count" +
                    " FROM Item";
        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            try
            {
               
              
                if (Code_txt.Text.Trim()!="")
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    where = " Where ID ='" + Code_txt.Text + "' ";
                    query += where;


                    // query += where;
                    SqlCommand command = new SqlCommand(query, con);
                    command.CommandType = CommandType.Text;
                    adapter = new SqlDataAdapter();
                    // Set the SqlDataAdapter's SelectCommand.
                    adapter.SelectCommand = command;

                    // Fill the DataSet.
                    DataSet dataSet = new DataSet();
                    adapter.Fill(dataSet, "Item");

                    con.Close();
                    query = "SELECT ID," +
                     "Brand," +
                     "Type," +
                     "gender," +
                     "Season," +
                     "Price," +
                     "Store_Count" +
                     " FROM Item";


                    Item_dataGridView.DataSource = dataSet.Tables["Item"];

                }
                else
                {

                    ERROR_WIN FOORM = new ERROR_WIN("يجب إدخال كود القطعة");
                    FOORM.ShowDialog(this);
                    return;
                }
              

                //    client_dataGridView.Rows[0].Selected = false;
           //     con.Close();
            }
            catch (Exception ex)
            {
              
            }
        }

        public void Item_dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void StoreDetails_Screen_Load(object sender, EventArgs e)
        {
            //    Item_dataGridView.Size.Height = Item_dataGridView.RowCount * 5;
            StoreDetails.BackColor = Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            StoreDetails.Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
         
            // query += where;
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Item");

         //   con.Close();

            Item_dataGridView.DataSource = dataSet.Tables["Item"];


            //    client_dataGridView.Rows[0].Selected = false;
            con.Close();





        }

        private void searchClear_btn_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            query = "SELECT ID," +
                     "Brand," +
                     "Type," +
                     "gender," +
                     "Season," +
                     "Price," +
                     "Store_Count" +
                     " FROM Item";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Item");

            //   con.Close();

            Item_dataGridView.DataSource = dataSet.Tables["Item"];

            //    client_dataGridView.Rows[0].Selected = false;
            con.Close();
            Code_txt.Text = string.Empty;
        }

        private void Item_dataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
        
            
    
         //   searchClear_btn.Select();
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();

                clientSearch_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click_1(object sender, EventArgs e)
        {

            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void AddClientBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }

        private void Item_dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string Item_id = Item_dataGridView.SelectedRows[0].Cells[0].Value.ToString();
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                query = "SELECT ID," +
                         "Brand," +
                         "Type," +
                         "gender," +
                         "Store_Count," +
                         "Price," +
                         "Season" +
                        " FROM Item " +
                        "Where ID= '" + Item_id + "'";
                SqlCommand command = new SqlCommand(query, con);
                command.CommandType = CommandType.Text;
                adapter = new SqlDataAdapter();
                // Set the SqlDataAdapter's SelectCommand.
                adapter.SelectCommand = command;

                // Fill the DataSet.
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "Item");
                DataRow dataRow = dataSet.Tables["Item"].Rows[0];

                AddItem_Screen form = new AddItem_Screen();
                form.ItemID_txt.Text = dataRow["ID"].ToString();
                form.Brand_txt.Text = dataRow["Brand"].ToString();
                form.price_txt.Text = dataRow["Price"].ToString();
                form.type_txt.Text = dataRow["Type"].ToString();
                form.Store_count_txt.Text = dataRow["Store_Count"].ToString();
                string gender = dataRow["gender"].ToString();
                //     gender = type_box.SelectedItem.ToString();
                form.type_box.Text = gender;
                string season = dataRow["Season"].ToString();
                if (season.Trim() == "شتوي")
                    form.winter_radioBtn.Checked = true;
                else
                    form.summer_radioBtn.Checked = true;

                form.Save_btn.Visible = false;
                form.update_btn.Visible = true;
                form.ItemID = Item_id;
                form.ItemID_txt.Enabled = false;

                form.Show();
                this.Hide();


                con.Close();
            }
            catch
            {
                ERROR_WIN FOORM = new ERROR_WIN("خطأ");
                FOORM.ShowDialog(this);
                return;
            }
        }
    }
}
