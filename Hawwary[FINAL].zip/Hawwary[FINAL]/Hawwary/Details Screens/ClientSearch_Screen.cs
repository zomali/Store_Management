﻿using Hawwary.Add_Screens;
using MissionsDB.messagebox;
//using Hawwary.Details_Screens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hawwary
{
    public partial class ClientSearch_Screen : Form
    {
        String query;
        SqlConnection con;
        SqlDataAdapter adapter;
        string connection_string;
        public string MyPage;
        public bool ADMIN_FLG;

        public ClientSearch_Screen()
        {
            InitializeComponent();
            MyPage = "ClientSearch";
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
            query = "SELECT ID," +
                "Name," +
               "Telephone," +
               "Address," +
               "Num_Of_Items," +
               "Total_Payments," +
               "Delivery_Charges," +
               "Notes" +
               " FROM Client ";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ClientSearch_Screen_Load(object sender, EventArgs e)
        {
            if (ADMIN_FLG == false)
            {
                AddPaymentBtn.Enabled = false;
                AddClientBtn.Enabled = false;
                AddPaymentBtn.Enabled = false;
                StoreDetails.Enabled = false;
                AddItemBtn.Enabled = false;
                showBtn.Enabled = false;
                toolStripButton1.Enabled = false;
                ADD_Representative.Enabled = false;
                Add_User.Enabled = false;
            }
            ClientSearch.BackColor = Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            ClientSearch.Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
           
         //   query += where;
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Client");

            con.Close();

            client_dataGridView.DataSource = dataSet.Tables["Client"];

            //    client_dataGridView.Rows[0].Selected = false;
            con.Close();

        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            try
            {

                string where = " Where Client.ID >=1 ";
                if (name_txt.Text != "")
                {
                    where += "and Client.Name LIKE  '%" + name_txt.Text.Trim().ToString() + "%' ";
                }
                if (phone_txt.Text != "")
                {
                    where += "and Client.Telephone = '" + phone_txt.Text.Trim().ToString() + "' ";
                }
                if (address_txt.Text != "")
                {
                    where += "and Client.Address LIKE  '%" + address_txt.Text.Trim().ToString() + "%' ";
                }
              
             
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                query += where;
                SqlCommand command = new SqlCommand(query, con);
                command.CommandType = CommandType.Text;
                adapter = new SqlDataAdapter();
                // Set the SqlDataAdapter's SelectCommand.
                adapter.SelectCommand = command;

                // Fill the DataSet.
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "Client");

             //   con.Close();

                client_dataGridView.DataSource = dataSet.Tables["Client"];
                if (dataSet.Tables["Client"].Rows.Count == 0)
                {
                    MessageBox.Show("خطأ في الادخال");
                }

                //    client_dataGridView.Rows[0].Selected = false;
                con.Close();
                query = "SELECT ID," +
               "Name," +
              "Telephone," +
              "Address," +
              "Num_Of_Items," +
              "Total_Payments," +
              "Delivery_Charges," +
              "Notes" +
              " FROM Client ";

            }
            catch
            {
               
                ERROR_WIN FOORM = new ERROR_WIN("هذا العميل ليس موجود");
                FOORM.ShowDialog(this);
                return;
            }
           
          
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void phone_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void address_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void name_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void searchClear_btn_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            query = "SELECT ID," +
                  "Name," +
                 "Telephone," +
                 "Address," +
                 "Num_Of_Items," +
                 "Total_Payments," +
                 "Delivery_Charges," +
                 "Notes" +
                 " FROM Client ";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Client");

            con.Close();

            client_dataGridView.DataSource = dataSet.Tables["Client"];

            //    client_dataGridView.Rows[0].Selected = false;
            con.Close();
            address_txt.Text=string.Empty;
            name_txt.Text=string.Empty;
            phone_txt.Text=string.Empty;
        }

        private void client_dataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
  
        }

        private void client_dataGridView_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int client_id;
            client_id = int.Parse(client_dataGridView.SelectedRows[0].Cells[0].Value.ToString());


            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            query = "SELECT Name," +
                       "Telephone," +
                       "Address" +
                       " FROM Client " +
                       "Where ID='" + client_id + "'";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Client");

            DataRow dataRow = dataSet.Tables["Client"].Rows[0];

            string Name = dataRow["Name"].ToString();
            string Telephone = dataRow["Telephone"].ToString();
            string Address = dataRow["Address"].ToString();

            //    float Price = float.Parse(dataRow["Price"].ToString());
            con.Close();




            PaymentDetails_Screen form = new PaymentDetails_Screen();
            form.ClientID = client_id;
            form.ClientName = Name;
            form.ClientAddress = Address;
            form.ClientPhone = Telephone;
            if(ADMIN_FLG==true)
            {
                form.ADMIN_FLG = true;

            }
            form.Show();
            this.Hide();
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {

            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();

                clientSearch_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
            if (ADMIN_FLG == true)
            {
                mainWindwo_Screen.ADMIN_FLG = true;

            }
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();

                clientSearch_Screen.Show();
                this.Hide();
            }
        }

        private void AddClientBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }
    }
}
