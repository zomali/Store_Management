﻿using Hawwary.Add_Screens;
using MissionsDB.messagebox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hawwary
{
    public partial class ShowReport_Screen : Form
    {
        String query;
        String where;

        public string MyPage;
        SqlConnection con;
        SqlDataAdapter adapter;
        string connection_string;
        float Amount=0;
        float Money_back=0;
        float discount=0;
        float given_money=0;
        float total_amount = 0;
        public ShowReport_Screen()
        {
            InitializeComponent();
            MyPage = "ShowReport";
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
            query = "SELECT ID," +
                    "Name," +
                    "Amount," +
                    "Money_Back," +
                    "discount," +
                    "Given_Money," +
                    "Total_Amount" +

                    " FROM Report";
           // Item_dataGridView.column
        }

        private void Search_btn_Click(object sender, EventArgs e)
        {
            try
            {

                string where = " Where ID >=1 ";
                //if (name_txt.Text.Trim() != "")
                //{
                if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    if (name_txt.Text != "")
                    {
                        where += "and Name LIKE  '%" + name_txt.Text.Trim().ToString() + "%' ";
                    }
                string d = DateTime_box.Value.Month + "/" + DateTime_box.Value.Day + "/" + DateTime_box.Value.Year;
                    if (DateTime_box.Text != "")
                    {
                        where += "and Date = '" +d + "' ";
                    }




                    //    where += "and Client.Name LIKE  '%" + name_txt.Text.Trim().ToString() + "%' ";
            //        where = " Where Name  LIKE  '%" + name_txt.Text + "%' ";
                    query += where;


                    // query += where;
                    SqlCommand command = new SqlCommand(query, con);
                    command.CommandType = CommandType.Text;
                    adapter = new SqlDataAdapter();
                    // Set the SqlDataAdapter's SelectCommand.
                    adapter.SelectCommand = command;

                    // Fill the DataSet.
                    DataSet dataSet = new DataSet();
                    adapter.Fill(dataSet, "Report");

                    con.Close();
                    query = "SELECT ID," +
                    "Name," +
                    "Amount," +
                    "Money_Back," +
                    "discount," +
                    "Total_Amount, " +
                    "Given_Money" +

                    " FROM Report";


                    Item_dataGridView.DataSource = dataSet.Tables["Report"];
        //     con.Close();
            }
            catch (Exception ex)
            {
            
                ERROR_WIN FOORM = new ERROR_WIN("لا يوجد قطعه بهذا الكود");
                FOORM.ShowDialog(this);
                return;
            }
        }
    

        private void ShowReport_Screen_Load(object sender, EventArgs e)
        {
            //     DateTime_box.Value.;
            showBtn.BackColor = Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            showBtn.Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold);
            //    Item_dataGridView.Size.Height = Item_dataGridView.RowCount * 5;
            //   StoreDetails.BackColor = Color.AliceBlue;
            //Segoe UI Semibold, 10.8pt, style=Bold
            //    StoreDetails.Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            // query += where;
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Report");

            //   con.Close();

            Item_dataGridView.DataSource = dataSet.Tables["Report"];


            //    client_dataGridView.Rows[0].Selected = false;
            con.Close();
            for(int i=0;i<Item_dataGridView.Rows.Count;i++) {
                Amount += Convert.ToInt32(Item_dataGridView.Rows[i].Cells[2].Value);
                Money_back += Convert.ToInt32(Item_dataGridView.Rows[i].Cells[3].Value);
                discount += Convert.ToInt32(Item_dataGridView.Rows[i].Cells[4].Value);
                given_money += Convert.ToInt32(Item_dataGridView.Rows[i].Cells[5].Value);
                total_amount += Convert.ToInt32(Item_dataGridView.Rows[i].Cells[6].Value);

            }
            amount_lbl.Text = Amount.ToString();
            MoneyBack_lbl.Text = Money_back.ToString();
            discount_lbl.Text = discount.ToString();
            givenMoney_lbl.Text = given_money.ToString();
            total_lbl.Text = total_amount.ToString();
   
        }

        private void ShowReport_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Item_dataGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void Item_dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
         
        }

        private void Item_dataGridView_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
        }

        private void Item_dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string Representative_id = Item_dataGridView.SelectedRows[0].Cells[0].Value.ToString();
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                query = "SELECT ID," +
                        "Name, " +
                         "Amount, " +
                        "Money_Back," +
                        "discount," +
                        "Given_Money," +
                        "Line," +
                        "Num_Of_Items," +
                        "Delivery," +
                        "Still," +
                         "Cancel," +
                        "Notes," +
                         "Total_Amount," +
                         "Date" +
                        " FROM Report " +
                        "Where ID= '" + Representative_id + "'";
                SqlCommand command = new SqlCommand(query, con);
                command.CommandType = CommandType.Text;
                adapter = new SqlDataAdapter();
                // Set the SqlDataAdapter's SelectCommand.
                adapter.SelectCommand = command;

                // Fill the DataSet.
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "Report");
                DataRow dataRow = dataSet.Tables["Report"].Rows[0];
                DataSet data = new DataSet();
                // data = <DataSet>( dataRow["Name"]);
                AddReport_Screen form = new AddReport_Screen();
                 
                form.names_box.Text = dataRow["Name"].ToString();
                form.names_box.Enabled= false;
                form.total_txt.Text = dataRow["Amount"].ToString();
                form.MoneyBack_txt.Text = dataRow["Money_Back"].ToString();
                form.givenMoney_txt.Text = dataRow["Given_Money"].ToString();
                form.discount_txt.Text = dataRow["discount"].ToString();
                form.line_txt.Text = dataRow["Line"].ToString();
                form.NumOfItems_txt.Text = dataRow["Num_Of_Items"].ToString();
                form.delivery_txt.Text = dataRow["Delivery"].ToString();
                form.still_txt.Text = dataRow["Still"].ToString();
                form.cancel_txt.Text = dataRow["Cancel"].ToString();
                form.Notes_txt.Text = dataRow["Notes"].ToString();
                form.DateTime_txt.Text = dataRow["Date"].ToString();
                form.representative_id = Representative_id;

                form.update_btn.Visible= true;
                form.Save_btn.Visible= false;
                form.button1.Visible= false;
               // form.DateTime_txt = new DateTime(2012, 05, 28);
                this.Hide();
                form.Show();



                con.Close();
            }
            catch
            {
                MessageBox.Show(" خطأ");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void searchClear_btn_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            query = "SELECT ID," +
                      "Name," +
                      "Amount," +
                      "Money_Back," +
                      "discount," +
                      "Given_Money," +
                      "Total_Amount" +

                      " FROM Report";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;
            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "Report");

            //   con.Close();

            Item_dataGridView.DataSource = dataSet.Tables["Report"];

            //    client_dataGridView.Rows[0].Selected = false;
            con.Close();
            name_txt.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
           if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();

            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }
    }
}
