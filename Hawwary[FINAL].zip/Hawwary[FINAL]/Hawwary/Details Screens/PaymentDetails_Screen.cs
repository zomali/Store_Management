﻿using Hawwary.Add_Screens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hawwary
{
    public partial class PaymentDetails_Screen : Form
    {
        String query;
        SqlConnection con;
        SqlDataAdapter adapter;
        public string MyPage;

        string connection_string;

        public bool ADMIN_FLG;
        public int    ClientID ;
        public String ClientName ;
        public string ClientPhone;
        public String ClientAddress;


        public PaymentDetails_Screen()
        {

            InitializeComponent();
            MyPage = "PaymentDetails";
            connection_string = "Data Source=desktop-6d1n4pj\\mssqlserver02;Initial Catalog=HawwaryDB;Integrated Security=True";
            con = new SqlConnection(connection_string);
        }

        private void PaymentDetails_Screen_Load(object sender, EventArgs e)
        {
            if (ADMIN_FLG == false)
            {
                AddPaymentBtn.Enabled = false;
                AddClientBtn.Enabled = false;
                AddPaymentBtn.Enabled = false;
                StoreDetails.Enabled = false;
                AddItemBtn.Enabled = false;
                showBtn.Enabled = false;
                toolStripButton1.Enabled = false;
                ADD_Representative.Enabled = false;
                Add_User.Enabled = false;

            }
            name_txt.Text = ClientName;
            phone_txt.Text = ClientPhone;
            address_txt.Text = ClientAddress;


            List<int> Colors_IDs_List = new List<int>();


            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            string query = "Select ItemID," +
                "Delivery_Way,Status," +
                "Notes,Date from Client_Item " +
                "Where ClientID='"+ClientID +"'";
            SqlCommand command = new SqlCommand(query, con);
            command.CommandType = CommandType.Text;


            adapter = new SqlDataAdapter();
            // Set the SqlDataAdapter's SelectCommand.
            adapter.SelectCommand = command;

            // Fill the DataSet.
            DataSet dataSet = new DataSet();

            adapter.Fill(dataSet, "Client_Item");

            // color_box.Text = ;

            PaymentDetailsData.DataSource = dataSet.Tables["Client_Item"];


            con.Close();

        }

        private void MainBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
         //       this.Hide();
            }
        }

        private void AddClientBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void AddPaymentBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();

                clientSearch_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void PaymentDetails_Screen_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainWindwo_Screen mainWindwo_Screen = new MainWindwo_Screen();
            mainWindwo_Screen.Show();
            this.Hide();
        }

        private void MainBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "Main")
            {
                MainWindwo_Screen form = new MainWindwo_Screen();

                form.Show();
                form.paymentDetails_Screen = this;
            //    this.Hide();
            }
        }

        private void AddPaymentBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddPayment")
            {
                AddPayment_Screen addPayment_Screen = new AddPayment_Screen();

                addPayment_Screen.Show();
                this.Hide();
            }
        }

        private void ClientSearch_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "ClientSearch")
            {
                ClientSearch_Screen clientSearch_Screen = new ClientSearch_Screen();
                this.Hide();
                clientSearch_Screen.Show();
            }
        }

        private void AddClientBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddClient")
            {
                AddClient_Screen addClient_Screen = new AddClient_Screen();

                addClient_Screen.Show();
                this.Hide();
            }
        }

        private void StoreDetails_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "StoreDetails")
            {
                StoreDetails_Screen storeDetails_Screen = new StoreDetails_Screen();

                storeDetails_Screen.Show();
                this.Hide();
            }
        }

        private void AddItemBtn_Click_1(object sender, EventArgs e)
        {
            if (MyPage != "AddItem")
            {
                AddItem_Screen addItem_Screen = new AddItem_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (MyPage != "AddReport")
            {
                AddReport_Screen addItem_Screen = new AddReport_Screen();
                addItem_Screen.update_btn.Visible = false;

                addItem_Screen.Show();
                this.Hide();
            }
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            if (MyPage != "ShowReport")
            {
                ShowReport_Screen showReport_Screen = new ShowReport_Screen();
                showReport_Screen.Show();
                this.Hide();
            }
        }

        private void ADD_Representative_Click(object sender, EventArgs e)
        {
            if (MyPage != "Register")
            {
                Register_Screen register_Screen = new Register_Screen();
                register_Screen.Show();
                this.Hide();
            }
        }

        private void Add_User_Click(object sender, EventArgs e)
        {
            if (MyPage != "ChangePassword")
            {
                ChangePassword_Screen changePassword_Screen = new ChangePassword_Screen();
                changePassword_Screen.Show();
                this.Hide();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            ClientSearch_Screen form = new ClientSearch_Screen();
            if (ADMIN_FLG == true)
            {
                form.ADMIN_FLG = true;

            }
            form.Show();
           this.Hide();
        }
    }
}
