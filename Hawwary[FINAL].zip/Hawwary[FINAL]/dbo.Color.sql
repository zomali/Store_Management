﻿CREATE TABLE [dbo].[Color] (
    [ID]    INT          IDENTITY (1, 1) NOT NULL,
    [Color] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

