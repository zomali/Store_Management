﻿CREATE TABLE [dbo].[Client] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [Name]             VARCHAR (255)  NULL,
    [Telephone]        NVARCHAR (50)  NULL,
    [Address]          NVARCHAR (MAX) NULL,
    [Num_Of_Items]     INT      DEFAULT 0 NOT NULL,
    [Total_Payments]   FLOAT (53)     NULL,
    [Delivery_Charges] FLOAT (53)     NULL,
    [Notes]            NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

