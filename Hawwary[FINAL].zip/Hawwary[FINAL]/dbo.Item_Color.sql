﻿CREATE TABLE [dbo].[Item_Color] (
    [ID]      INT           NOT NULL,
    [ItemID]  NVARCHAR (50) NULL,
    [ColorID] INT           NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC),
	FOREIGN KEY ([ItemID]) REFERENCES Item(ID),
	FOREIGN KEY ([ColorID]) REFERENCES Color(ID),
);

