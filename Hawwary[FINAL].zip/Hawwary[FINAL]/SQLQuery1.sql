﻿CREATE TABLE [dbo].[Report]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Total] FLOAT NOT NULL, 
    [Money_Back] NCHAR(10) NULL, 
    [discount] NCHAR(10) NULL, 
    [Line] NVARCHAR(50) NULL, 
    [Num_Of_Items] INT NOT NULL, 
    [Delivery] INT NULL, 
    [Still] INT NULL, 
    [Cancel] INT NULL, 
    [Notes] NVARCHAR(MAX) NULL, 
    [Date] NVARCHAR(50) NOT NULL
)
